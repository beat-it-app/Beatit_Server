package com.beat_it.team.entity

import com.beat_it.global.entity.BaseCreatedTimeEntity
import com.beat_it.team.entity.enum.ReactionType
import jakarta.persistence.Column
import jakarta.persistence.Entity
import jakarta.persistence.EnumType
import jakarta.persistence.Enumerated
import jakarta.persistence.FetchType
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id
import jakarta.persistence.JoinColumn
import jakarta.persistence.ManyToOne
import jakarta.persistence.Table
import jakarta.persistence.UniqueConstraint

@Entity
@Table(
    name = "archive_reactions",
    uniqueConstraints = [
        UniqueConstraint(
            name = "uk_archive_reactions_archive_user",
            columnNames = ["archive_id", "user_id"],
        ),
    ],
)
class ArchiveReactions(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "archive_reaction_id", nullable = false)
    val archiveReactionId: Long? = null,

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "archive_id", nullable = false)
    val archive: Archives,

    @Column(name = "user_id", nullable = false)
    val userId: Long,

    @Enumerated(EnumType.STRING)
    @Column(name = "reaction_type", nullable = false)
    val reactionType: ReactionType,

) : BaseCreatedTimeEntity()
