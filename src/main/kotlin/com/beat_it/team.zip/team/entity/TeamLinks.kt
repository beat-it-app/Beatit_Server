package com.beat_it.team.entity

import com.beat_it.global.entity.BaseUpdatedTimeEntity
import com.beat_it.team.entity.enum.PlatformCode
import com.beat_it.team.entity.enum.TeamRole
import io.swagger.v3.oas.annotations.links.Link
import jakarta.persistence.*
import java.time.OffsetDateTime

@Entity
@Table(name = "team_links")
class TeamLinks(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="team_link_id", nullable = false)
    val teamLinkId: Long? = null,

    //TODO: 팀 ID 연결하기
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "team_id", nullable = false)
    val team: Teams,

    @Enumerated(EnumType.STRING)
    @Column(name="platform_code",nullable = false)
    var platformCode: PlatformCode = PlatformCode.CUSTOM,

    @Column(name="link_url",nullable = false)
    var linkUrl: String = "",

//    @Column(name="update_at",nullable = false)
//    var updateAt: OffsetDateTime = OffsetDateTime.now(),
//
//    @Column(name="create_at",nullable = false)
//    val createdAt: OffsetDateTime = OffsetDateTime.now(),

) : BaseUpdatedTimeEntity() {
    fun updateLink(platformCode: PlatformCode, linkUrl: String) {
        this.platformCode = platformCode
        this.linkUrl = linkUrl
    }
}