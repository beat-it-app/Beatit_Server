package com.beat_it.team.controller

import com.beat_it.auth.dto.WithdrawalRequest
import com.beat_it.auth.dto.WithdrawalResponse
import com.beat_it.global.error.BusinessException
import com.beat_it.global.error.ErrorCode
import com.beat_it.team.service.TeamService
import com.beat_it.global.response.BasicResponse
import com.beat_it.team.dto.*
import io.swagger.v3.oas.annotations.Operation
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import java.util.UUID
import io.swagger.v3.oas.annotations.tags.Tag
import jakarta.validation.Valid
import org.springframework.security.core.annotation.AuthenticationPrincipal
import org.springframework.security.core.userdetails.UserDetails

@Tag(name = "2-1. TEAM API", description = "팀 관련 로직")
@RestController
@RequestMapping("/teams")
class TeamController(
    private val teamService: TeamService,
) {

    @Operation(summary = "팀 생성하기")
    @PostMapping
    fun createTeam(
        @AuthenticationPrincipal userDetails: UserDetails,
        @RequestBody request: TeamCreateRequest
    ): ResponseEntity<BasicResponse<TeamCreateResponse>> {
        val userId = extractUserId(userDetails)
        val responseData = teamService.createTeam(userId, request)

        return ResponseEntity
            .status(HttpStatus.CREATED)
            .body(BasicResponse.success(responseData, HttpStatus.CREATED, "팀이 성공적으로 생성되었습니다."))
    }

    @Operation(summary = "팀 수정하기")
    @PatchMapping
    fun updateTeamDetail(
        @AuthenticationPrincipal userDetails: UserDetails,
        @RequestBody request: TeamDetailUpdateRequest,
    ): ResponseEntity<BasicResponse<TeamDetailUpdateResponse>> {
        val userId = extractUserId(userDetails)
        val responseData = teamService.updateTeamDetail(userId, request)

        return ResponseEntity
            .status(HttpStatus.OK)
            .body(BasicResponse.success(responseData, HttpStatus.OK, "팀 상세 내용이 성공적으로 수정되었습니다."))
    }

    @Operation(summary = "팀 삭제하기")
    @DeleteMapping("/{teamPublicId}")
    fun deleteTeam(
        @AuthenticationPrincipal userDetails: UserDetails,
        @PathVariable teamPublicId: UUID
    ): ResponseEntity<BasicResponse<Nothing>> {
        val userId = extractUserId(userDetails)
        teamService.deleteTeam(userId, teamPublicId)

        return ResponseEntity
            .status(HttpStatus.OK)
            .body(BasicResponse.success(HttpStatus.OK, "팀이 성공적으로 삭제되었습니다."))
    }

    @Operation(summary = "팀 페이지 불러오기")
    @GetMapping
    fun getTeamDetail(
        @AuthenticationPrincipal userDetails: UserDetails
    ): ResponseEntity<BasicResponse<out Any>> {
        val userId = extractUserId(userDetails)

        val teamDetail = teamService.getTeamDetail(userId)

        if (teamDetail != null) {
            return ResponseEntity
                .status(HttpStatus.OK)
                .body(BasicResponse.success(teamDetail, HttpStatus.OK, "팀 상세 내용 조회에 성공했습니다."))
        }

        val userTeams = teamService.getUserTeams(userId)

        if (userTeams.teams.isEmpty()) {
            return ResponseEntity
                .status(HttpStatus.OK)
                .body(BasicResponse.success(HttpStatus.OK, "소속된 팀이 없습니다. 팀을 생성하거나 초대코드를 입력하세요."))
        } else {
            return ResponseEntity
                .status(HttpStatus.OK)
                .body(BasicResponse.success(userTeams, HttpStatus.OK, "선택된 팀이 없어 소속된 팀 리스트를 반환합니다."))
        }
    }

    @Operation(summary = "로그인할 팀 선택하기")
    @PostMapping("/select/{teamPublicId}")
    fun selectTeam(
        @AuthenticationPrincipal userDetails: UserDetails,
        @PathVariable teamPublicId: UUID,
    ): ResponseEntity<BasicResponse<Nothing>> {
        val userId = extractUserId(userDetails)

        teamService.selectTeam(userId, teamPublicId)

        return ResponseEntity
            .status(HttpStatus.OK)
            .body(BasicResponse.success(HttpStatus.OK, "팀이 성공적으로 선택되었습니다."))
    }

    @Operation(summary = "초대코드로 팀 가입하기")
    @PostMapping( "/join/{inviteCode}")
    fun postJoinTeam(
        @AuthenticationPrincipal userDetails: UserDetails,
        @PathVariable inviteCode: String,
    ): ResponseEntity<BasicResponse<TeamJoinResponse>> {
        val userId = extractUserId(userDetails)

        val responseData = teamService.joinTeam(userId, inviteCode)

        return ResponseEntity
            .status(HttpStatus.OK)
            .body(BasicResponse.success(responseData, HttpStatus.OK, "팀 가입이 완료되었습니다."))
    }

    @Operation(summary = "내 팀 목록 확인하기")
    @GetMapping("/me")
    fun getMyTeams(
        @AuthenticationPrincipal userDetails: UserDetails,
    ): ResponseEntity<BasicResponse<UserTeamListResponse>> {
        val userId = extractUserId(userDetails)

        val responseData = teamService.getUserTeams(userId)

        return ResponseEntity
            .status(HttpStatus.OK)
            .body(BasicResponse.success(responseData, HttpStatus.OK, "나의 팀 리스트 조회에 성공했습니다."))
    }

    @Operation(summary = "초대코드의 팀 정보 조회")
    @GetMapping("/verify/{inviteCode}")
    fun getVerifyCode(
        @PathVariable inviteCode: String,
    ): ResponseEntity<BasicResponse<TeamSimpleInfo>> {
        val responseData = teamService.getTeamInfoByInviteCode(inviteCode)

        return ResponseEntity
            .status(HttpStatus.OK)
            .body(BasicResponse.success(responseData, HttpStatus.OK, "팀 초대 링크 조회에 성공했습니다."))
    }

    @Operation(summary = "멤버 목록 확인하기")
    @GetMapping("/members")
    fun getMembers(
        @AuthenticationPrincipal userDetails: UserDetails,
    ): ResponseEntity<BasicResponse<TeamMemberListResponse>>{
        val userId = extractUserId(userDetails)

        val responseData = teamService.getTeamMembers(userId)

        return ResponseEntity
            .status(HttpStatus.OK)
            .body(BasicResponse.success(responseData, HttpStatus.OK, "팀 멤버 목록 조회에 성공했습니다."))
    }

    @Operation(summary = "멤버 권한 바꾸기")
    @PostMapping("/members/{userPublicId}")
    fun postManageMember(
        @AuthenticationPrincipal userDetails: UserDetails,
        @PathVariable userPublicId: UUID,
        @RequestBody request: TeamManageRequest,
    ): ResponseEntity<BasicResponse<TeamManageResponse>> {
        val userId = extractUserId(userDetails)

        val responseData = teamService.updateMemberRole(request, userId, userPublicId)

        return ResponseEntity
            .status(HttpStatus.OK)
            .body(BasicResponse.success(responseData, HttpStatus.OK, "멤버 권한이 성공적으로 변경되었습니다."))
    }

    @Operation(summary = "팀 탈퇴하기")
    @PostMapping("/withdraw/{teamPublicId}")
    fun withdrawTeam(
        @AuthenticationPrincipal userDetails: UserDetails,
        @PathVariable teamPublicId: UUID
    ): ResponseEntity<BasicResponse<com.beat_it.team.dto.TeamWithdrawalResponse>> {
        val userId = extractUserId(userDetails)

        val responseData = teamService.teamWithdraw(userId, teamPublicId)

        return ResponseEntity.ok(
            BasicResponse.success(responseData, HttpStatus.OK, "팀 탈퇴 요청이 정상적으로 접수되었습니다. 7일의 유예기간 후 완전히 탈퇴 처리됩니다.")
        )
    }

    private fun extractUserId(userDetails: UserDetails): Long {
        return userDetails.username.toLongOrNull()
            ?: throw BusinessException(ErrorCode.UNAUTHORIZED)
    }
}

