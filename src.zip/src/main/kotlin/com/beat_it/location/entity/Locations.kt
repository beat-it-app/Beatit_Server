package com.beat_it.location.entity

import com.beat_it.global.entity.BaseUpdatedTimeEntity
import jakarta.persistence.*
import java.math.BigDecimal

@Entity
@Table(name = "locations")
class Locations(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "location_id", nullable = false)
    val locationId: Long? = null,

    @Column(name = "user_id", nullable = false)
    val userId: Long,

    @Column(name = "location_name", length = 200)
    var locationName: String? = null,

    @Column(name = "road_address", length = 255)
    var roadAddress: String? = null,

    @Column(name = "latitude", precision = 10, scale = 7)
    var latitude: BigDecimal? = null,

    @Column(name = "longitude", precision = 10, scale = 7)
    var longitude: BigDecimal? = null,

    @Column(name = "map_url", length = 500)
    var mapUrl: String? = null,

    @Column(name = "phone", length = 50)
    var phone: String? = null,

    @Column(name = "kakao_place_id", length = 50)
    var kakaoPlaceId: String? = null,

    @Column(name = "jibun_address", length = 255)
    var jibunAddress: String? = null,
) : BaseUpdatedTimeEntity() {

    fun updateLocation(
        locationName: String?,
        roadAddress: String?,
        latitude: BigDecimal?,
        longitude: BigDecimal?,
        mapUrl: String?,
        phone: String?,
        kakaoPlaceId: String?,
        jibunAddress: String?
    ) {
        locationName?.let { this.locationName = it }
        roadAddress?.let { this.roadAddress = it }
        latitude?.let { this.latitude = it }
        longitude?.let { this.longitude = it }
        mapUrl?.let { this.mapUrl = it }
        phone?.let { this.phone = it }
        kakaoPlaceId?.let { this.kakaoPlaceId = it }
        jibunAddress?.let { this.jibunAddress = it }
    }
}
